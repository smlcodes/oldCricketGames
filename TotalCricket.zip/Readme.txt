Total Cricket version 1.0

Installation :

Just unzip the file Totalcricket.zip into any directory and run Totalcric.exe to play the game.

Please note that you must have the following vb dlls for the game to run properly:

msvbvm60.dll
OLEAUT32.DLL
OLEPRO32.DLL
ASYCFILT.DLL
Stdole2.tlb
COMCAT.DLL
MSIMG32.DLL
Comdlg32.ocx
MSCHRT20.OCX


If the game gives you an error regarding any of these dlls then 
please download these additional files and unzip them into your windows\system directory.

Msvbvm60.dll can be downloaded from :
http://www.dll-files.com/dllindex/dll-files.shtml?msvbvm60

mschrt20.ocx can be downloaded from :
http://www.cricketweb.net/tc/mschrt20.zip

OLEAUT32.DLL can be downloaded from :
http://www.cricketweb.net/tc/oleaut32.zip

All the other files in compressed form can be downloaded at :
http://www.cricketweb.net/tc/otherfiles.zip

The visual basic runtimes can be found at :
http://www.cricketweb.net/downloadscentre/essentials/essentials.shtml


Bugs and other Support:
If you have any suggestions or any bug to report then please mail to any of the following mail ids:
sriram_k@myiris.com
sumit4@hotpop.com

For any further information on the game pls visit :
http://www.cricketweb.net/tc which will be updated soon!! :)







