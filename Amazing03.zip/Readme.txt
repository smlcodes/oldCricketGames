Amazing Cricket 2003
�Sumit Chowdhury, 2003.

Release Notes:-

I recently got hold of the new Microsoft OS called Windows XP. The XP visual styles are just brilliant. While I was playing this game, I noticed that the visual styles are missing. I took out some time and implemented the XP visual styles for the Windows XP community. In the meanwhile, some more optimizations and a few changes were made to get the game working more realistically. Noticable among these are the Improved Artificial Intelligence and a Single Player Mode.

Attention Please:-

The visual styles are available only in Windows XP. To reduce the size of this installation package and to make the download faster for you, I haven't included the VB6 Runtime Files. However, the files are absolutely necessary to run the program successfully. Please check if your system have the following files:

1) Asycfilt.dll
2) Comcat.dll
3) Msvbvm60.dll
4) Oleaut32.dll
5) Olepro32.dll
6) Stdole2.tlb

If they are not present, you can download the VB6 Runtime Files from any one of the following websites:

http://www.microsoft.com
http://www.simtel.net
http://www.zdnet.com

Thanks a lot,
Sumit Chowdhury.