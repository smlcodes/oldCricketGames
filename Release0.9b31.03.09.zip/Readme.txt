Install Instructions:

Extract the contents of the archive to a folder on your computer (Maintaining the folder structure of the archive)

To run the application, you must have the Java Runtime Environment installed
Available from: http://www.java.com/

Once installed, run the file called ArmchairCricket.jar
If you are prompted to choose a program to open the file with, configure Java to open the file type, or use the Debug.bat file to launch instead.

Some notes:

Two card shots are not fully working yet.
Multiplayer mode is disabled for this release.

Thanks & Enjoy!

Peter Bouquet

With thanks to: cricinfo.com, flags.net & cricketeurope.net for images & stats.